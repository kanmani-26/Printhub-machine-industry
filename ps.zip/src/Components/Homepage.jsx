import React from "react";
import './app1.css';
import { FaFacebookF, FaTwitter, FaInstagram, FaLinkedin, FaEnvelope, FaPhoneAlt, FaMapMarkerAlt } from 'react-icons/fa';

const Home = () => {
  return (
    <main className="landing-page">
      <section className="hero">
        <img
          src="/mac.jfif" 
          alt="Printing Machine"
          className="hero-image"
        />

        <div className="hero-text">
          <h1>Revolutionizing Printing Technology</h1>
          <p>Discover the future of printing with Print Hub Machine Industries.</p>
          <div className="hero-buttons">
            <a href="#features" className="btn explore-btn">
              Explore More
            </a>
            <a href="#video" className="btn video-btn">
              Watch Video
            </a>
          </div>
        </div>
      </section>

      <section id="features" className="features-section">
        <h2>Key Features</h2>
        <div className="features-container">
          <div className="feature-item">
            <h3>High Precision</h3>
            <p>Experience unparalleled accuracy in every print job.</p>
          </div>
          <div className="feature-item">
            <h3>Eco-Friendly</h3>
            <p>Built with sustainability in mind, reducing waste.</p>
          </div>
          <div className="feature-item">
            <h3>Easy Integration</h3>
            <p>Seamlessly integrates with your existing systems.</p>
          </div>
          <div className="feature-item">
            <h3>Fast Printing</h3>
            <p>Achieve faster printing speeds without compromising quality.</p>
          </div>
          <div className="feature-item">
            <h3>Durable Build</h3>
            <p>Manufactured with robust materials for long-lasting performance.</p>
          </div>
          <div className="feature-item">
            <h3>Customizable Options</h3>
            <p>Tailor settings to suit specific printing requirements.</p>
          </div>
   
        </div>
      </section>

      <section id="video" className="video-section">
        <h2>Watch Our Technology in Action</h2>
        <div className="video-container">
          <iframe
            width="560"
            height="315"
            src="/mavdo.mp4" 
            title="YouTube video player"
            // frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </section> 
        <footer className="footer">
            <div className="footer-content">
                {/* Contact Section */}
                <div className="footer-section contact-section">
                    <h4>Contact Us</h4>
                    <p><FaEnvelope /> <a href="mailto:manikandanprints@gmail.com">manikandanprints@gmail.com</a></p>
                    <p><FaPhoneAlt /> <a href="tel:+919442431996">+91 94424 31996</a></p>
                    <p><FaMapMarkerAlt /> <a>Naranapuram Road, Amman Nagar, Sivakasi.</a></p>
                </div>

                {/* Quick Links Section */}
                <div className="footer-section links-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#features">Features</a></li>
                        <li><a href="#video">Video</a></li>
                        <li><a href="/about">About Us</a></li>
                        <li><a href="/contact">Contact</a></li>
                    </ul>
                </div>

                {/* Social Media Section */}
                <div className="footer-section social-section">
                    <h4>Follow Us</h4>
                    <div className="social-media">
                        <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer"><FaFacebookF /> Facebook</a>
                        <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer"><FaTwitter /> Twitter</a>
                        <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer"><FaInstagram /> Instagram</a>
                        <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer"><FaLinkedin /> LinkedIn</a>
                    </div>
                </div>
            </div>

            {/* Footer Bottom Section */}
            <div className="footer-bottom">
                <p>&copy; 2025 Print Hub Machine Industries. All rights reserved.</p>
            </div>
        </footer>
    </main>
  );
};
export default Home;
