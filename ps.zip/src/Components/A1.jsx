import React, { useEffect, useState } from "react";
import { collection, getDocs, updateDoc, deleteDoc, doc, onSnapshot } from "firebase/firestore";
import "./app1.css";
import { db } from "../firebase";

export const A1 = () => {
    const [users, setUsers] = useState([]);
    const [services, setServices] = useState([]);
    const [manufactures, setManufactures] = useState([]);
    const [sales, setSales] = useState([]);
    const [activeTab, setActiveTab] = useState("dashboard");

    const [data, setData] = useState([]);

    // Fetch users from Firestore
    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const usersRef = collection(db, "register");
                const querySnapshot = await getDocs(usersRef);
                setUsers(querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
            } catch (error) {
                console.error("Error fetching users:", error.message);
            }
        };
        fetchUsers();
    }, []);

    // Fetch services from Firestore
    useEffect(() => {
        const fetchServices = async () => {
            try {
                const servicesRef = collection(db, "services");
                const querySnapshot = await getDocs(servicesRef);
                setServices(querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
            } catch (error) {
                console.error("Error fetching services:", error.message);
            }
        };
        fetchServices();
    }, []);
    //Fetch Sales record

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, "form1"), (snapshot) => {
            const salesData = snapshot.docs.map((doc) => ({
                id: doc.id,
                ...doc.data(),
            }));
            console.log("Fetched Sales Data:", salesData);
            setData(salesData);
        });

        return () => unsubscribe();
    }, []);

    const deleteSale = async (id) => {
        try {
            await deleteDoc(doc(db, "form1", id));
            setData((prevData) => prevData.filter((sale) => sale.id !== id));
            console.log("Sale deleted successfully.");
        } catch (error) {
            console.error("Error deleting sale:", error.message);
        }
    };


    // Fetch manufactures from Firestore
    useEffect(() => {
        const fetchManufactures = async () => {
            try {
                const manufacturesRef = collection(db, "customizationRequests");
                const querySnapshot = await getDocs(manufacturesRef);
                setManufactures(querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
            } catch (error) {
                console.error("Error fetching manufactures:", error.message);
            }
        };

        fetchManufactures();
    }, [db]);

    const togglePaymentStatus = async (id, currentStatus) => {
        const newStatus = currentStatus === 'received' ? 'Pending' : 'received';
        try {
          const docRef = doc(db, "customizationRequests", id);
          await updateDoc(docRef, { status: newStatus });
          alert(`Payment status updated to ${newStatus}`);
          setManufactures((prev) => prev.map((item) => item.id === id ? { ...item, status: newStatus } : item));
        } catch (error) {
          console.error("Error updating status:", error);
          alert("Failed to update payment status.");
        }
      };
    // Delete a manufacture record
    const deleteManufacture = async (id) => {
        try {
            await deleteDoc(doc(db, "customizationRequests", id));
            setManufactures((prev) => prev.filter((manufacture) => manufacture.id !== id));
        } catch (error) {
            console.error("Error deleting manufacture:", error.message);
        }
    };

    // Mark a service request as viewed
    const markAsViewed = async (id) => {
        try {
            const serviceRef = doc(db, "services", id);
            await updateDoc(serviceRef, { viewed: true });

            // Update UI after marking as viewed
            setServices((prev) =>
                prev.map((service) =>
                    service.id === id ? { ...service, viewed: true } : service
                )
            );

            console.log(`Service ID ${id} marked as viewed ✅`);
        } catch (error) {
            console.error("Error updating service status:", error.message);
        }
    };
    const verifyPayment = async (serviceId) => {
        try {
            const serviceRef = doc(db, "services", serviceId);
            await updateDoc(serviceRef, {
                PaymentStatus: "verified"
            });
            alert("Payment verified successfully!");
        } catch (error) {
            console.error("Error updating payment status:", error);
            alert("Failed to verify payment.");
        }
    };
    // Delete a user record
    const deleteUser = async (id) => {
        await deleteDoc(doc(db, "register", id));
        setUsers((prev) => prev.filter((user) => user.id !== id));
    };
    return (
        <div className="dashboard-container">
            {/* Sidebar */}
            <aside className="sidebar">
                <h2 className="logo1">PrintHub</h2>
                <ul className="menu">
                    <li className={activeTab === "dashboard" ? "active" : ""} onClick={() => setActiveTab("dashboard")}>📊 Dashboard</li>
                    <li className={activeTab === "users" ? "active" : ""} onClick={() => setActiveTab("users")}>💳 Users</li>
                    <li className={activeTab === "services" ? "active" : ""} onClick={() => setActiveTab("services")}>📋 Services</li>
                    <li className={activeTab === "sales" ? "active" : ""} onClick={() => setActiveTab("sales")}>📋 Sales</li>
                    <li className={activeTab === "manufactures" ? "active" : ""} onClick={() => setActiveTab("manufactures")}>📋 Manufactures</li>
                </ul>
            </aside>

            {/* Main Content */}
            <main className="main-content">
                {activeTab === "dashboard" && (
                    <section className="dashboard">
                        <h2>Dashboard</h2>
                        <div className="dashboard1">
                            <div className="stats">
                                <div className="stat-box purple">
                                    <span>👥</span>
                                    <h3>{users.length}</h3>
                                    <p>New Users</p>
                                </div>
                                <div className="stat-box purple">
                                    <span>📋</span>
                                    <h3>{services.filter(service => service.viewed).length}</h3>
                                    <p>Services Viewed</p>
                                </div>
                                <div className="stat-box purple">
                                    <span>📋</span>
                                    <h3>{sales.length}</h3>
                                    <p>Total Sales</p>
                                </div>
                                <div className="stat-box purple">
                                    <span>📋</span>
                                    <h3>{manufactures.length}</h3>
                                    <p>Total Production</p>
                                </div>
                            </div>
                        </div>
                    </section>
                )}

                {/* Users Table */}
                {activeTab === "users" && (
                    <div className="users-table">
                        <h2>Users</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                </tr>
                            </thead>
                            <tbody>
                                {users.map((user) => (
                                    <tr key={user.id}>
                                        <td>{user.Name}</td>
                                        <td>{user.Email}</td>
                                        <td>
                                            <button onClick={() => deleteUser(user.id)}>❌ Delete</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

                {/* Services Table */}
                {activeTab === "services" && (
                    <div className="service-table">
                        <h2>Services</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Location</th>
                                    <th>ServiceType</th>
                                    <th>Phone</th>
                                    <th>Message</th>
                                    <th>Viewed</th>
                                    <th>Action</th>
                                    <th>ScreenShots</th>
                                    <th>PaymentStatus</th>
                                </tr>
                            </thead>
                            <tbody>
                                {services.map((service) => (
                                    <tr key={service.id}>
                                        <td>{service.ServiceId}</td>
                                        <td>{service.Name}</td>
                                        <td>{service.Email}</td>
                                        <td>{service.Location}</td>
                                        <td>{service.Phone}</td>
                                        <td>{service.Service}</td>
                                        <td>{service.Message}</td>
                                        <td>{service.viewed ? "✅ Yes" : "❌ No"}</td>
                                        <td>
                                            {!service.viewed && (
                                                <button onClick={() => markAsViewed(service.id)}>Mark as Viewed</button>
                                            )}
                                        </td>
                                        <td>  {service.PaymentScreenshot ? (
                                            <img
                                                src={`data:image/png;base64,${service.PaymentScreenshot.split(",")[1]}`} // Ensure correct format
                                                alt="Screenshot"
                                                style={{ width: "50px", height: "50px", cursor: "pointer", borderRadius: "5px" }}
                                                onClick={() => {
                                                    const newTab = window.open();
                                                    newTab.document.write(`<img src="data:image/png;base64,${service.PaymentScreenshot.split(",")[1]}" style="width:100%">`);
                                                    newTab.document.close();
                                                }}
                                            />
                                        ) : (
                                            "No Screenshot"
                                        )}
                                        </td>
                                        <td>
                                            {service.paymentStatus === "verified" ? (
                                                <span style={{ color: "green", fontWeight: "bold" }}>✅ Payment Success. Service in Progress.</span>
                                            ) : (
                                                <div>
                                                    {service.PaymentScreenshot ? (
                                                        <>
                                                            <img
                                                                src={`data:image/png;base64,${service.PaymentScreenshot.split(",")[1]}`}
                                                                alt="Screenshot"
                                                                style={{ width: "50px", height: "50px", cursor: "pointer", borderRadius: "5px" }}
                                                                onClick={() => {
                                                                    const newTab = window.open();
                                                                    newTab.document.write(`<img src="data:image/png;base64,${service.PaymentScreenshot.split(",")[1]}" style="width:100%">`);
                                                                    newTab.document.close();
                                                                }}
                                                            />
                                                            <button onClick={() => verifyPayment(service.id)}>Verify Payment</button>
                                                        </>
                                                    ) : (
                                                        "No Screenshot"
                                                    )}
                                                </div>
                                            )}
                                        </td>

                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )
                }

                {/* Sales Table */}
                {activeTab === "sales" && (
                    <div className="sales-table">
                        <h2>Sales</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Contact</th>
                                    <th>Email</th>
                                    <th>Company Name</th>
                                    <th>Company Address</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.length > 0 ? (
                                    data.map((item) => (
                                        <tr key={item.id}>
                                            <td>{item.name || "N/A"}</td>
                                            <td>{item.contact || "N/A"}</td>
                                            <td>{item.email || "N/A"}</td>
                                            <td>{item.companyName || "N/A"}</td>
                                            <td>{item.companyAddress || "N/A"}</td>
                                            <td>
                                                <button onClick={() => deleteSale(item.id)}>❌ Delete</button>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="6">No data available</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                )}
                {/* Manufactures Table */}
                {activeTab === "manufactures" && (
                    <div className="manufactures-table">
                        <h2>Manufactures</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>CompanyName</th>
                                    <th>Company Address</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>TransactionId</th>
                                    <th>Date/Time</th>

                                </tr>
                            </thead>
                            <tbody>
                                {manufactures.map((manufacture) => (
                                    <tr key={manufacture.id}>
                                        <td>{manufacture.name}</td>
                                        <td>{manufacture.company}</td>
                                        <td>{manufacture.address}</td>
                                        <td>{manufacture.email}</td>
                                        <td>{manufacture.phone}</td>
                                        <td>{manufacture.description}</td>
                                        <td>{manufacture.status}</td>
                                        <td>{manufacture.transactionId}</td>
                                        <td>{manufacture.timestamp?.toDate?.().toLocaleString()}</td>
                                        <td>
                                            <button onClick={() => togglePaymentStatus(manufacture.id, manufacture.status)}>
                                                {manufacture.status === 'received' ? 'Mark as Pending' : 'Mark as Received'}
                                            </button>
                                        </td>
                                        {/* Delete Button */}
                                        <td>
                                            <button onClick={() => deleteManufacture(manufacture.id)}>❌ Delete</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>

                        </table>
                    </div>
                )
                }
            </main >
        </div >
    );
};