import React from 'react'
import './app1.css';
export const S2 = () => {
    return (
        <main className="landing-page">
            <div class="container">
        <div class="section-title"><h3>Our Popular Services</h3></div>
        <div class="section-description">We provide high-quality printing machines with excellent support, maintenance, and installation services worldwide.</div>
        
        <div class="services">
            <div class="service-box">
                <img src="s1.jpg" alt="Automatic Screen Printing Machine"></img>
                <div class="service-name">Automatic Screen Printing Machine</div>
                <div class="service-description">High-speed automatic printing with precision and efficiency.</div>
                <div class="service-location">Location: Chennai, India</div>
            </div>
            
            <div class="service-box">
                <img src="s2.jpg" alt="Rotary Screen Printing Machine"></img>
                <div class="service-name">Rotary Screen Printing Machine</div>
                <div class="service-description">Designed for bulk production with multi-color printing.</div>
                <div class="service-location">Location: Mumbai, India</div>
            </div>
            
            <div class="service-box">
                <img src="s3.jpg" alt="Manual Screen Printing Press"></img>
                <div class="service-name">Manual Screen Printing Press</div>
                <div class="service-description">Perfect for small businesses and beginners.</div>
                <div class="service-location">Location: Bangalore, India</div>
            </div>
        </div>
        <div class="services1">
            <div class="service-box">
                <img src="offsett.webp" alt="Automatic Screen Printing Machine"></img>
                <div class="service-name">Offset Screen Printing Machine</div>
                <div class="service-description">High-speed automatic printing with precision and efficiency.</div>
                <div class="service-location">Location: Chennai, India</div>
            </div>
            
            <div class="service-box">
                <img src="offset.webp" alt="Rotary Screen Printing Machine"></img>
                <div class="service-name">TexScreen X Machine</div>
                <div class="service-description">Designed for bulk production with multi-color printing.</div>
                <div class="service-location">Location: Mumbai, India</div>
            </div>
            
            <div class="service-box">
                <img src="digital.webp" alt="Manual Screen Printing Press"></img>
                <div class="service-name">Digital Screen Printing Press</div>
                <div class="service-description">Perfect for small businesses and beginners.</div>
                <div class="service-location">Location: Bangalore, India</div>
            </div>
        </div>
    </div>

        </main>
    );
};
