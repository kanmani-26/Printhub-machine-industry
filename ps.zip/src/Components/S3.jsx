import React from 'react'
import './app1.css';

export const S3 = () => {
    return (
        <div>
            <section class="why-us">
                <h4>Why Choose Us</h4>
                <ul class="accordian">
                    <li>
                        <input type="radio" name="accordian" id="first" checked></input>
                        <label for="first">24/7 Support</label>
                        <div class="content1">
                            {/* <img src="images/a2.webp" width="50" height="150"></img> */}
                            <p>PrintHub  offer round-the-clock assistance via phone, email, and remote access to resolve technical issues anytime.
                                Our expert support team ensures minimal downtime, providing quick troubleshooting and guidance.</p>
                        </div>
                    </li>
                    <li>
                        <input type="radio" name="accordian" id="second"></input>
                        <label for="second">Machine Installation & Training</label>
                        <div class="content1">
                            {/* <img src="images/a3.jpg" width="50" height="150"></img> */}
                            <p>Our technicians handle on-site installation, ensuring proper setup and calibration of your printing machines.
                                We provide hands-on training, manuals, and video guides to help operators use machines efficiently.</p>
                        </div>
                    </li>
                    <li>
                        <input type="radio" name="accordian" id="third"></input>
                        <label for="third">Preventive Maintenance & Repairs</label>
                        <div class="content1">
                            {/* <img src="images/a4.jpg" width="50" height="150"></img> */}
                            <p>Regular scheduled maintenance prevents breakdowns and extends machine lifespan.
                                We offer on-demand repair services with skilled engineers for quick issue resolution.</p>
                        </div>
                    </li>
                    <li>
                        <input type="radio" name="accordian" id="fourth"></input>
                        <label for="fourth">Spare Parts & Consumables Supply</label>
                        <div class="content1">
                            {/* <img src="images/a4.jpg" width="50" height="150"></img> */}
                            <p>We supply original spare parts and essential consumables like screens, squeegees, and inks.
                                Our fast delivery service ensures that your production line runs smoothly without long waiting times.</p>
                        </div>
                    </li>
                </ul>
                </section>
        </div>
    );
};
