// src/firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore"; // For Firestore
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCKdP2n6O3cqc1JyvbBbdf9seYeSAYtf-Y",
  // authDomain: "YOUR_AUTH_DOMAIN",
  // projectId: "YOUR_PROJECT_ID",
  // storageBucket: "YOUR_STORAGE_BUCKET",
  // messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  // appId: "YOUR_APP_ID"
  authDomain: "printhub-c00ae.firebaseapp.com",
  projectId: "printhub-c00ae",
  storageBucket: "printhub-c00ae.firebasestorage.app",
  messagingSenderId: "507807331759",
  appId: "1:507807331759:web:14632aaef7a78a188a6b5a",
  // measurementId: "G-8MFYF3C3PP"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app); // Firestore
export const auth = getAuth(app); 
