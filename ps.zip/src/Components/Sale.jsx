import React from 'react'
import { useNavigate } from "react-router-dom";
import './sales.css';

const machinesData = [
    {
      id: 1,
      name: "EconoPrint 3000",
      image: "one.jpg",
      price: 150000,
      description: "A compact and efficient screen printing machine, ideal for small businesses.",
      location: "Chennai, Tamil Nadu",
      company: "PrintTech Solutions",
    },
    {
      id: 2,
      name: "ProPrint XL",
      image: "two.jpg",
      price: 250000,
      description: "A high-performance machine suitable for bulk printing projects.",
      location: "Coimbatore, Tamil Nadu",
      company: "Coimbatore Printers Co.",
    },
    {
      id: 3,
      name: "QuickScreen Lite",
      image: "three1.jpg",
      price: 180000,
      description: "Lightweight and portable, perfect for mobile screen printing jobs.",
      location: "Madurai, Tamil Nadu",
      company: "Madurai Print Solutions",
    },
    {
      id: 4,
      name: "MasterPress 500",
      image: "three.jpg",
      price: 300000,
      description: "A premium machine offering precision and durability for professional use.",
      location: "Tiruchirappalli, Tamil Nadu",
      company: "Trichy Tech Printers",
    },
    {
      id: 5,
      name: "ScreenJet Ultra",
      image: "five.jpg",
      price: 350000,
      description: "Advanced automation features for high-speed production environments.",
      location: "Salem, Tamil Nadu",
      company: "Salem Screen Tech",
    },
    {
      id: 6,
      name: "EcoPress Mini",
      image: "six.jpg",
      price: 120000,
      description: "Environmentally friendly and energy-efficient, ideal for startups.",
      location: "Erode, Tamil Nadu",
      company: "Erode Green Press",
    },
  ];
  
export const Sale = () => {
    const navigate = useNavigate();

  const handleBuyNow = (id) => {
    navigate(`/machine/${id}`);
  };

  return (
    <div className="sales-container">
      <h1>Ready to Sale</h1>
      <div className="machines-grid">
        {machinesData.map((machine) => (
          <div key={machine.id} className="machine-card">
            <img src={machine.image} alt={machine.name} />
            <h3>{machine.name}</h3>
            <p>{machine.description}</p>
            <p>Price: ₹ {machine.price}</p>
            <button onClick={() => handleBuyNow(machine.id)}>View Details</button>
          </div>
        ))}
      </div>
    </div>
    
  );
};
