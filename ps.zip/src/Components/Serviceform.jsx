import React, { useState, useEffect } from "react";
import { collection, addDoc, query, where, onSnapshot, doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import { v4 as uuidv4 } from "uuid";
import './app1.css'

export const Serviceform = () => {
    const [serviceId, setServiceId] = useState("");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [location, setLocation] = useState("");
    const [service, setService] = useState("");
    const [message, setMessage] = useState("");
    const [status, setStatus] = useState("Sent");
    const [showStatus, setShowStatus] = useState(false);
    const [documentId, setDocumentId] = useState("");
    const [showQR, setShowQR] = useState(false);
    const [qrCodeUrl, setQrCodeUrl] = useState("");
    const [screenshot, setScreenshot] = useState("");
    const [uploading, setUploading] = useState(false);
    const amount = 1;

    useEffect(() => {
        setServiceId(uuidv4().slice(0, 8));
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await addDoc(collection(db, "services"), {
                ServiceId: serviceId,
                Name: name,
                Email: email,
                Phone: phone,
                Location: location,
                Service: service,
                Message: message,
                Status: "Sent",
                PaymentStatus:false,
            });
            alert("Service Request Submitted!");
        } catch (error) {
            console.error("Error submitting request:", error);
            alert("Submission failed. Try again!");
        }
    };

    const checkStatus = async () => {
        const enteredId = document.getElementById("checkId").value.trim();
        if (!enteredId) {
            alert("Please enter your Service ID");
            return;
        }

        const serviceQuery = query(collection(db, "services"), where("ServiceId", "==", enteredId));

        onSnapshot(serviceQuery, (querySnapshot) => {
            if (querySnapshot.empty) {
                alert("Service ID not found!");
                return;
            }

            const docData = querySnapshot.docs[0].data();
            setDocumentId(querySnapshot.docs[0].id);

            if (docData.viewed == true && docData.PaymentStatus==false) {
                setStatus("Admin Viewed");
            } else if(docData.viewed==true && docData.PaymentStatus=="verified"){
                setStatus("Payment Received");
            }
            else{
                setStatus("Pending");
            }
            setShowStatus(true);
        });
    };

    const handlePayment = async () => {
        if (!documentId) {
            alert("Error updating status. Try again!");
            return;
        }

        try {
            await updateDoc(doc(db, "services", documentId), { Status: "Payment" });
            generateQrCode();
            setShowQR(true);
        } catch (error) {
            console.error("Error updating payment status:", error);
            alert("Failed to update status.");
        }
    };
    const confirmPayment = async () => {
        if (!documentId) {
            alert("Error confirming payment. Try again!");
            return;
        }

        try {
            await updateDoc(doc(db, "services", documentId), { Status: "Payment" });
            setStatus("Payment");
        } catch (error) {
            console.error("Error updating payment status:", error);
            alert("Failed to confirm payment.");
        }
    };

    const generateQrCode = () => {
        const upiLink = `upi://pay?pa=your_upi_id@upi&pn=YourName&am=${amount}.00&cu=INR`;
        const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiLink)}`;
        setQrCodeUrl(qrApiUrl);
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onloadend = () => {
                setScreenshot(reader.result); // Base64 string
            };
        }
    };
    
    useEffect(() => {
        const fetchDocumentId = async () => {
            const querySnapshot = await getDocs(collection(db, "customizationRequests"));
            querySnapshot.forEach((doc) => {
                console.log("Document ID:", doc.id);
                setDocumentId(doc.id); // Assuming you are fetching a single document
            });
        };
        fetchDocumentId();
    }, []);
    
    const handleUpload = async () => {
        console.log("Screenshot:", screenshot);
        console.log("Document ID:", documentId);
        if (!screenshot || !documentId) {
            alert("Please select a file and check your status.");
            return;
        }

        setUploading(true);

        try {
            await updateDoc(doc(db, "services", documentId), {
                PaymentScreenshot: screenshot,
            });

            alert("Screenshot uploaded successfully!");
        } catch (error) {
            console.error("Error uploading file:", error);
            alert("Upload failed, please try again.");
        }
        setUploading(false);
    };

    return (
        <main className="landing-page">
            <div className="section">
                <div className="form-container2">
                    <div className="form-box1">
                        <h2>Service Request Form</h2>
                        <form onSubmit={handleSubmit}>
                            <input type="text" value={serviceId} readOnly />
                            <input type="text" placeholder="Your Name" value={name} onChange={(e) => setName(e.target.value)} required />
                            <input type="email" placeholder="Your Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                            <input type="tel" placeholder="Your Phone Number" value={phone} onChange={(e) => setPhone(e.target.value)} required />
                            <input type="text" placeholder="Your Location" value={location} onChange={(e) => setLocation(e.target.value)} required />
                            <select value={service} onChange={(e) => setService(e.target.value)}>
                                <option value="printing">Printing Service</option>
                                <option value="maintenance">Maintenance Service</option>
                                <option value="installation">Installation Service</option>
                            </select>
                            <textarea placeholder="Your Message" value={message} onChange={(e) => setMessage(e.target.value)} required></textarea>
                            <button type="submit">Submit Request</button>
                        </form>
                    </div>

                    <div className="form-container1">
                        <div className="form-box1">
                            <h2>Check Your Service Request Status</h2>
                            <input type="text" id="checkId" placeholder="Enter Your Service ID" />
                            <button onClick={checkStatus}>Check Status</button>
                        </div>

                       
                        {showStatus && (
                            <div className="status-message">
                                <h3>Status: {status}</h3>
                                {status === "Admin Viewed" && !showQR && (
                                    <button className="payment-button" onClick={handlePayment}>Proceed to Payment</button>
                                )}
                                {showQR && status !== "Payment Success" && (
                                    <div className="qr-section">
                                        <h3>Scan to Pay ₹{amount}</h3>
                                        <img src="https://raw.githubusercontent.com/Dhivyalakshmi12/PrintHub1/refs/heads/main/qr.jpeg" alt="QR Code for Payment" className="qr-code" />
                                        <input className="fileimg"type="file" accept="image/*" onChange={handleFileChange} />
                                        <button className="upload-button" onClick={handleUpload} disabled={uploading}>
                                            {uploading ? "Uploading..." : "Upload Payment Screenshot"}
                                        </button>
                                    </div>
                                )}
                                {status === "Payment Success" && <p>✅ Payment received! Your service is in progress.</p>}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </main>
    );
};
