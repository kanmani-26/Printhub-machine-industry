import React from 'react'
import Navbar from './Navbar'
import { S1 } from './S1';
import { S2 } from './S2';
import { S3 } from './S3';
import { Serviceform } from './Serviceform';
import { Footer } from './Footer';
export const Service = () => {
  return (
        <>
        <Navbar />
        <S1 />
        <S3/>
         <S2/>  
         <Serviceform/>
         <Footer/> 
        </>
  );
};
