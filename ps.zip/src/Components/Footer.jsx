import React from 'react'
import './Footer.css';
import { FaFacebookF, FaTwitter, FaInstagram, FaLinkedin, FaEnvelope, FaPhoneAlt, FaMapMarkerAlt } from 'react-icons/fa';

export const Footer = () => {
    return (
        <div>
            <footer class="footer1">
                <div class="footer-container1">
                    <div class="footer-section1">
                        <h3>Contact Us</h3>
                        <p><FaEnvelope /> <a href="mailto:manikandanprints@gmail.com">    manikandanprints@gmail.com</a></p>
                        <p><FaPhoneAlt /> <a href="tel:+919442431996">    +91 94424 31996</a></p>
                        <p><FaMapMarkerAlt /> <a>    Naranapuram Road, Amman Nagar, Sivakasi.</a></p>
                    </div>
                    <div class="footer-section1">
                        <h3>Quick Links</h3>
                        <a href="#"><i className="fas fa-angle-right"></i> Features</a>
                        <a href="#"><i className="fas fa-angle-right"></i> Video</a>
                        <a href="#"><i className="fas fa-angle-right"></i> About Us</a>
                        <a href="#"><i className="fas fa-angle-right"></i> Contact</a>
                    </div>
                    <div class="footer-section1">
                        <h3>Follow Us</h3>
                        <div class="social-icons1">
                            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer"><FaFacebookF /> Facebook</a>
                            <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer"><FaTwitter /> Twitter</a>
                            <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer"><FaInstagram /> Instagram</a>
                            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer"><FaLinkedin /> LinkedIn</a>
                        </div>
                    </div>
                </div>
                <div class="copyright1">&copy; 2025 Print Hub Machine Industries. All rights reserved.</div>
            </footer>
        </div>
    );
};
