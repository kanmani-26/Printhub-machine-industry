import React from "react";
import { Link } from "react-router-dom";
import './app1.css';

const Navbar = () => {
  return (
    <header className="navbar">
      <div className="logo">Print Hub Machine Industries</div>
      <nav>
        <ul className="nav-links">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/new-arrival">New Arrival</Link></li>
          <li><Link to="/manufactures">Our Manufacture</Link></li>
          <li><Link to="/service">Our Service</Link></li>
          <li><Link to="/sales">Our Sales</Link></li>
          <li><Link to="/about">About</Link></li>
          {/* <li><Link to="/admin">Admin</Link></li>  */}
          <li><Link to="/register" className="contact-btn">Register</Link></li>
          <li><Link to="/login" className="contact-btn">Login</Link></li>
        </ul>
      </nav>
    </header>
  );
};

export default Navbar;
