import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Components/Navbar';
import Home from './Components/Homepage';
import { Register } from './Components/Register';
import Login from './Components/Login';
import { Service } from './Components/Service';
import { Sales } from './Components/Sales';
import { Admin } from './Components/Admin';
import { Machine } from './Components/Machine';
import MachineDetails from './Components/MachineDetails';
import About from './Components/About';
import M2 from "./Components/M2";
import NewArrivals from './Components/NewArrivals';

const App = () => {
  return (
    <Router>
      <div>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />  
          <Route path="/about" element={<About />} />
          <Route path="/newarrivals" element={<NewArrivals />} /> 
          <Route path="/service" element={<Service />} />
          <Route path="/manufactures" element={<Machine />} />
          <Route path="/mac/:id" element={<M2 />} /> 
          <Route path="/sales" element={<Sales />} />
          <Route path="/machine/:id" element={<MachineDetails />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
