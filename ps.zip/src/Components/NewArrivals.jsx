import React from "react";
import { Truck, ShieldCheck, Headset, Users, Star, Package, CheckCircle, Wrench, Globe, DollarSign, Clock } from "lucide-react";
import './newarrivals.css';
import { S1 } from './S1';
import { Footer } from './Footer';

const newArrivalsData = [
  {
    id: 7,
    name: "TurboPress 800",
    image: "/A.jpg",
    description: "High-speed press for mass production with turbo efficiency.",
  },
  {
    id: 8,
    name: "FlexiPrint Z200",
    image: "/Bjpg.jpg",
    description: "Flexible, semi-automatic machine for small and medium-scale industries.",
  },
  {
    id: 9,
    name: "PowerScreen Elite",
    image: "/C.jpg",
    description: "Top-of-the-line machine with smart tech and touch interface.",
  },
  {
    id: 10,
    name: "AutoJet Pro",
    image: "/D.jpg",
    description: "Fully automatic, high-precision press for premium output.",
  },
  {
    id: 11,
    name: "SpeedMax 600",
    image: "/E.jpg",
    description: "Speed-focused machine with easy setup for fast turnarounds.",
  },
  {
    id: 12,
    name: "PrintX Innovator",
    image: "/14.jpg",
    description: "Innovative design with AI-based calibration for flawless prints.",
  },
  {
    id: 13,
    name: "EcoPrint 3000",
    image: "/13.jpg",
    description: "Eco-friendly machine with low energy consumption.",
  },
  {
    id: 14,
    name: "MaxFlow Turbo",
    image: "/12.jpg",
    description: "High-performance machine with turbocharged output.",
  }
  
];

const features = [
  { icon: <Truck size={32} />, title: "Fast Delivery", desc: "Quick shipping across India" },
  { icon: <ShieldCheck size={32} />, title: "Verified Quality", desc: "Machines checked & certified" },
  { icon: <Headset size={32} />, title: "24/7 Support", desc: "We're here for you anytime" },
  { icon: <Users size={32} />, title: "Trusted by 100+ Clients", desc: "Growing network of happy customers" },
  { icon: <Star size={32} />, title: "5-Star Rating", desc: "Top-rated by industry experts" },
  { icon: <Package size={32} />, title: "Secure Packaging", desc: "Guaranteed safe delivery" },
  { icon: <CheckCircle size={32} />, title: "Certified Excellence", desc: "Industry-standard certifications" },
  { icon: <Wrench size={32} />, title: "Easy Maintenance", desc: "Designed for hassle-free servicing" },
  { icon: <DollarSign size={32} />, title: "Best Pricing", desc: "Competitive rates with no hidden fees" },
  { icon: <Clock size={32} />, title: "On-Time Support", desc: "Prompt customer service round the clock" },
];

const NewArrivals = () => {
  return (
    <><S1/>
    <div className="new-arrivals-container">
      <h1>New Arrivals</h1>
      <div className="new-machines-grid">
        {newArrivalsData.map((machine) => (
          <div key={machine.id} className="new-machine-card">
            <img src={machine.image} alt={machine.name} />
            <h3>{machine.name}</h3>
            <p>{machine.description}</p>
          </div>
        ))}
      </div>
      <h2 className="feature-title">Why Choose Us?</h2>
      <div className="features-widgets">
        {features.map((feature, index) => (
          <div key={index} className="feature-card">
            {feature.icon}
            <h4>{feature.title}</h4>
            <p>{feature.desc}</p>
          </div>
        ))}
      </div>
    </div><Footer/></>
  );
};

export default NewArrivals;
