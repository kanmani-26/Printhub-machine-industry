import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import Slider from "react-slick";
import { QRCodeCanvas } from "qrcode.react";
import { db } from "../firebase";
import { collection, addDoc, doc, updateDoc, getDocs, query, where } from "firebase/firestore";
import { serverTimestamp } from "firebase/firestore";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./M2.css";

const M2 = () => {
    const [screenshot, setScreenshot] = useState("");
    const [uploading, setUploading] = useState(false);
    const [documentId, setDocumentId] = useState("");
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onloadend = () => {
                console.log("Screenshot set:", reader.result); // Debug log
                setScreenshot(reader.result); // Convert to Base64
            };
        }
    };
    useEffect(() => {
        const fetchDocumentId = async () => {
            try {
                const querySnapshot = await getDocs(collection(db, "customizationRequests"));
                querySnapshot.forEach((doc) => {
                    console.log("Document ID:", doc.id);
                    setDocumentId(doc.id);
                });
            } catch (error) {
                console.error("Error fetching document ID:", error);
            }
        };
        fetchDocumentId();
    }, []);
    const handleUpload = async () => {
        if (!screenshot || !documentId) {
            alert("Please select a screenshot and make sure documentId is set.");
            return;
        }

        setUploading(true);

        try {
            const docRef = doc(db, "customizationRequests", documentId);
            await updateDoc(docRef, {
                PaymentScreenshot: screenshot,
            });

            alert("Screenshot uploaded successfully!");
        } catch (error) {
            console.error("Error uploading file:", error);
            alert("Upload failed. Please try again.");
        } finally {
            setUploading(false);
        }
    };


    const { state } = useLocation();
    const mac = state?.mac;

    const [formData, setFormData] = useState({
        name: "",
        email: "",
        phone: "",
        address: "",
        company: "",
        description: "",
        transactionId: ""
    });

    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const validateForm = () => {
        const { name, email, phone, address, company, transactionId } = formData;
        if (!name || !email || !phone || !address || !company || !transactionId) {
            alert("All fields are required.");
            return false;
        }
        if (!/^[a-zA-Z ]+$/.test(name)) {
            alert("Please enter a valid name.");
            return false;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            alert("Please enter a valid email address.");
            return false;
        }
        if (!/^[0-9]{10}$/.test(phone)) {
            alert("Please enter a valid 10-digit phone number.");
            return false;
        }
        return true;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsLoading(true);

        try {
            await addDoc(collection(db, "customizationRequests"), {
                ...formData,
                amount: 5000,
                status: "Pending",
                // timestamp: new Date().toISOString()
                timestamp: serverTimestamp()

            });

            alert("Request submitted successfully!. Pay the amount Via the below QR code");
            setFormData({
                name: "",
                email: "",
                phone: "",
                address: "",
                company: "",
                description: "",
                transactionId: ""
            });
        } catch (error) {
            console.error("Error adding document: ", error);
            alert("Error submitting request. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    if (!mac) {
        return <h2 className="error-message">Machine details not found!</h2>;
    }

    return (
        <div className="machine-details-container">
            <h1 className="title">{mac.name}</h1>
            <p className="description">Customizations Available: {mac.customization}</p>

            <Slider dots infinite autoplay autoplaySpeed={3000} arrows>
                {mac.images.map((img, index) => (
                    <div key={index} className="slider-item">
                        <img src={img} alt={`${mac.name} - Image ${index + 1}`} className="slider-image" />
                    </div>
                ))}
            </Slider>

            <div className="customization-form">
                <h2>Request Customization</h2>
                <form onSubmit={handleSubmit}>
                    <input type="text" name="name" placeholder="Enter your name" value={formData.name} onChange={handleChange} required />
                    <input type="email" name="email" placeholder="Enter your email" value={formData.email} onChange={handleChange} required />
                    <input type="text" name="phone" placeholder="Enter your phone number" value={formData.phone} onChange={handleChange} required />
                    <input type="text" name="address" placeholder="Enter your address" value={formData.address} onChange={handleChange} required />
                    <input type="text" name="company" placeholder="Enter your company name" value={formData.company} onChange={handleChange} required />
                    <textarea name="description" placeholder="Describe your customization request" value={formData.description} onChange={handleChange} rows="4" required></textarea>
                    <input type="text" name="transactionId" placeholder="Enter your transaction ID" value={formData.transactionId} onChange={handleChange} required />

                    <button type="submitt" className="submitt-btn" disabled={isLoading}>
                        {isLoading ? "Submitting..." : "Submit Request"}
                    </button>
                </form>
            </div>

            <div className="qr-payment-section">
                <h2>Pay via QR Code</h2>
                <p>Scan the QR code below to pay <strong>₹5000</strong> securely:</p>
                <QRCodeCanvas value="https://raw.githubusercontent.com/Dhivyalakshmi12/PrintHub1/refs/heads/main/qr.jpeg" size={200} />
                <p>After payment, enter your Transaction ID below.</p>

            </div>
            <div className="check-status-section">
                <h2>Check Payment Status</h2>
                <input
                    type="text"
                    placeholder="Enter Transaction ID to Check Status"
                    value={formData.transactionId}
                    onChange={(e) => setFormData({ ...formData, transactionId: e.target.value.trim() })}
                />
                <button
                    className="check-status-btn"
                    onClick={async () => {
                        if (!formData.transactionId) {
                            alert("Please enter a Transaction ID.");
                            return;
                        }

                        try {
                            // Efficient query using Firestore where clause
                            const q = query(collection(db, "customizationRequests"), where("transactionId", "==", formData.transactionId));
                            const querySnapshot = await getDocs(q);

                            if (querySnapshot.empty) {
                                alert("Transaction ID not found. Please check and try again.");
                            } else {
                                querySnapshot.forEach((doc) => {
                                    const data = doc.data();
                                    alert(`Payment Status: ${data.status || "Pending"}`);
                                });
                            }
                        } catch (error) {
                            console.error("Error checking payment status:", error);
                            alert("Error checking status. Please try again.");
                        }
                    }}
                >
                    Check Status
                </button>
            </div>
        </div>
    );
};

export default M2;
