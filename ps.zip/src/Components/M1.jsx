import React from 'react'
import './M1.css';

export const M1 = () => {
  return (
    <>
        <section className="manufacture2">
      <div className="container2">
        <h1>Manufacturing Machines</h1>
        <p>
          At <strong>PrintHub Machine Industries</strong>, we specialize in
          advanced screen printing machines designed to meet the highest
          industry standards.
        </p>

        <h2>Our Manufacturing Process</h2>
        <div className="process2">
          <div className="step2">
            <h3>🔹 Design & Prototyping</h3>
            <p>Innovative designs tailored for quality and efficiency.</p>
          </div>
          <div className="step2">
            <h3>🔹 Material Selection</h3>
            <p>Premium materials ensure long-lasting durability.</p>
          </div>
          <div className="step2">
            <h3>🔹 Precision Engineering</h3>
            <p>Advanced manufacturing techniques for superior performance.</p>
          </div>
          <div className="step2">
            <h3>🔹 Quality Assurance</h3>
            <p>Rigorous testing to meet industry standards.</p>
          </div>
        </div>

        <h2>Why Choose Our Machines?</h2>
        <ul className="features2">
          <li>✔️ High-Speed & Precision Printing</li>
          <li>✔️ User-Friendly Interface</li>
          <li>✔️ Durable & Low Maintenance</li>
          <li>✔️ Customizable for Various Applications</li>
        </ul>

        <p className="contact2">
          For inquiries and custom requirements,{" "}
          <a href="contact.html">contact us today!</a>
        </p>
      </div>
    </section>

    </>
  );
};