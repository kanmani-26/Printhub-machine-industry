
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { db } from "../firebase";
import { collection, addDoc } from "firebase/firestore";
import "./MachineDetails.css";

const MachineDetails = () => {
  const { id } = useParams();

  const machinesData = [
    {
      id: 1,
      name: "EconoPrint 3000",
      image: "/one.jpg",
      price: 150000,
      description: "Compact and efficient screen printing machine.",
      location: "Chennai, Tamil Nadu",
      company: "PrintTech Solutions",
      speed: "100 prints/hour",
      power: "1.5 kW",
      buildQuality: "High Grade Steel",
      materialsUsed: "Aluminum, Steel",
      maxCapacity: "2000 prints/month",
      maintenance: "Low maintenance, recommended annual servicing",
    },
    {
      id: 2,
      name: "ProPrint XL",
      image: "/two.jpg",
      price: 250000,
      description: "High-performance bulk printing machine.",
      location: "Coimbatore, Tamil Nadu",
      company: "Coimbatore Printers Co.",
      speed: "250 prints/hour",
      power: "3 kW",
      buildQuality: "Reinforced Aluminum Frame",
      materialsUsed: "Stainless Steel, Alloy",
      maxCapacity: "5000 prints/month",
      maintenance: "Medium maintenance, servicing every 6 months",
    },
    {
      id: 3,
      name: "UltraPrint 5000",
      image: "/three.jpg",
      price: 350000,
      description: "Ultra-fast printing for industrial applications.",
      location: "Mumbai, Maharashtra",
      company: "Industrial Printers Ltd.",
      speed: "400 prints/hour",
      power: "5 kW",
      buildQuality: "Titanium Alloy Frame",
      materialsUsed: "Titanium, Steel",
      maxCapacity: "8000 prints/month",
      maintenance: "High maintenance, requires quarterly servicing",
    },
    {
      id: 4,
      name: "ScreenMaster 200",
      image: "/three1.jpg",
      price: 180000,
      description: "Affordable screen printing for small businesses.",
      location: "Delhi",
      company: "ScreenTech Solutions",
      speed: "120 prints/hour",
      power: "2 kW",
      buildQuality: "Aluminum Frame",
      materialsUsed: "Steel, Plastic",
      maxCapacity: "3000 prints/month",
      maintenance: "Low maintenance, annual servicing recommended",
    },
    {
      id: 5,
      name: "FlexiPrint 700",
      image: "/five.jpg",
      price: 275000,
      description: "Versatile printing solution with flexible settings.",
      location: "Hyderabad",
      company: "FlexPrint India",
      speed: "300 prints/hour",
      power: "4 kW",
      buildQuality: "Carbon Fiber Reinforced Frame",
      materialsUsed: "Carbon Fiber, Aluminum",
      maxCapacity: "6000 prints/month",
      maintenance: "Medium maintenance, requires bi-annual servicing",
    },
    {
      id: 6,
      name: "MegaPrint 9000",
      image: "/six.jpg",
      price: 500000,
      description: "Premium printing machine with AI-powered optimization.",
      location: "Bangalore",
      company: "AI Print Systems",
      speed: "600 prints/hour",
      power: "6 kW",
      buildQuality: "Industrial Grade Steel",
      materialsUsed: "Steel, Alloy, Plastic",
      maxCapacity: "10000 prints/month",
      maintenance: "Advanced maintenance, requires monthly check-ups",
    },
  ];

  const machine = machinesData.find((m) => m.id === parseInt(id));

  const [showPopup, setShowPopup] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    contact: "",
    email: "",
    companyName: "",
    companyAddress: "",
  });
  const [qrData, setQrData] = useState("");

  useEffect(() => {
    if (machine) {
      const amountToPay = (machine.price * 0.10).toFixed(2);
      const upiID = "yourupi@upi";  // Replace with actual UPI ID
      const merchantCode = "123456"; // Optional
      const transactionID = `TXN${Date.now()}`;
      const orderID = `ORD${Math.floor(Math.random() * 100000)}`;

      const qrPaymentLink = `upi://pay?pa=${upiID}&pn=Your+Business+Name&mc=${merchantCode}&tid=${transactionID}&tr=${orderID}&tn=Payment+for+Machine&am=${amountToPay}&cu=INR`;
      setQrData(qrPaymentLink);
    }
  }, [machine]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateForm = () => {
    const nameRegex = /^[A-Za-z ]+$/;
    const contactRegex = /^[0-9]{10}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const companyNameRegex = /^[A-Za-z0-9 ]+$/;
    
    if (!nameRegex.test(formData.name)) {
      alert("Invalid name. Only letters and spaces are allowed.");
      return false;
    }
    if (!contactRegex.test(formData.contact)) {
      alert("Invalid contact number. It must be a 10-digit number.");
      return false;
    }
    if (!emailRegex.test(formData.email)) {
      alert("Invalid email format.");
      return false;
    }
    if (!companyNameRegex.test(formData.companyName)) {
      alert("Invalid company name. Only alphanumeric characters and spaces are allowed.");
      return false;
    }
    if (formData.companyAddress.length < 5) {
      alert("Company address must be at least 5 characters long.");
      return false;
    }
    return true;
  };

  const handleProceed = () => {
    setShowPopup(false);
    alert("WE WILL CONTACT YOU SHORTLY...");
    setTimeout(() => setShowForm(true), 2000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      await addDoc(collection(db, "form1"), formData);
      setShowForm(false);
      setShowQR(true);
    } catch (error) {
      console.error("Error adding document: ", error);
      alert("Error: " + error.message);
    }
  };

  if (!machine) {
    return <h2>Machine not found!</h2>;
  }

  return (
    <div className="machine-details">
      <h2>Machine Details</h2>
      <img src={machine.image} alt={machine.name} />
      <h3>{machine.name}</h3>
      <p>{machine.description}</p>
      <p><strong>Price:</strong> ₹ {machine.price}</p>
      <p><strong>Location:</strong> {machine.location}</p>
      <p><strong>Company:</strong> {machine.company}</p>
      <p><strong>Speed:</strong> {machine.speed}</p>
      <p><strong>Power Consumption:</strong> {machine.power}</p>
      <p><strong>Build Quality:</strong> {machine.buildQuality}</p>
      <p><strong>Materials Used:</strong> {machine.materialsUsed}</p>
      <p><strong>Max Capacity:</strong> {machine.maxCapacity}</p>
      <p><strong>Maintenance:</strong> {machine.maintenance}</p>

      <button onClick={() => setShowPopup(true)}>Buy Now</button>

      {showPopup && (
        <div className="popup12">
          <p>Are you sure you want to buy this machine?</p>
          <button onClick={handleProceed}>Yes</button>
          <button onClick={() => setShowPopup(false)}>No</button>
        </div>
      )}

      {showForm && (
        <div className="form-container">
          <h4>Enter Your Details</h4>
          <form onSubmit={handleSubmit}>
            <input type="text" name="name" placeholder="Your Name" value={formData.name} onChange={handleInputChange} required />
            <input type="text" name="contact" placeholder="Your Contact Number" value={formData.contact} onChange={handleInputChange} required />
            <input type="email" name="email" placeholder="Your Email" value={formData.email} onChange={handleInputChange} required />
            <input type="text" name="companyName" placeholder="Company Name" value={formData.companyName} onChange={handleInputChange} required />
            <input type="text" name="companyAddress" placeholder="Company Address" value={formData.companyAddress} onChange={handleInputChange} required />
            
            <button type="submit">Proceed to Payment</button>
          </form>
        </div>
      )}

      {showQR && (
        <div className="qr-container">
          <h4>Secure Payment</h4>
          <p>Scan the QR code below to complete your payment.</p>
          <img src="https://raw.githubusercontent.com/Dhivyalakshmi12/PrintHub1/refs/heads/main/qr.jpeg" alt="Payment QR Code" width="256" height="256" />
          <p><strong>Pay 10%:</strong> ₹ {(machine.price * 0.10).toFixed(2)}</p>
          <p className="secure-text">🔒 Your transaction is secure and encrypted.</p>
        </div>
        
      )}
    </div>
    
  );
};

export default MachineDetails;
