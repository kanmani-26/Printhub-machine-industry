import React from "react";
import { useNavigate } from "react-router-dom";
import "./Manufacture.css";

const machines = [
    { id: 1, name: "Autoprint 1520 Colt", images: ["/111.jfif", "/111-1.webp"], customization: "Speed Optimization, Color Adjustment" },
    { id: 2, name: "Ryobi 520 Offset", images: ["/112.jfif", "/1122.jfif"], customization: "Software Update, Hardware Upgrade" },
    { id: 3, name: "Heidelberg K-offset machine", images: ["/1133.jpg", "/11331.jpg"], customization: "Color Adjustment, Software Update" },
    { id: 4, name: "Komori Lithrone L-528", images: ["/114.jpg", "/1141.jpg"], customization: "Hardware Upgrade, Speed Optimization" },
    { id: 5, name: "Semi-automatic Silk-screening Printing machine", images: ["/semi.jpg", "/semi2.jpg"], customization: "Speed Optimization, Color Adjustment" },
    { id: 6, name: "Semi Automatic Screen Printing Machine", images: ["/sa-4060f.jpg", "/sa-4060f2.jpg"], customization: "Software Update, Hardware Upgrade" },
    { id: 7, name: "FB-12070 Semi-Automatic and Large-Side Screen Printing Machine with CE", images: ["/SA-0906SCC2.jfif", "/sa-0906scc.jpg"], customization: "Color Adjustment, Software Update" },
    { id: 8, name: "Semi Automatic Round Screen Printing Machine", images: ["/112.jfif", "/1122.jfif"], customization: "Hardware Upgrade, Speed Optimization" },
];

const Manufacture = () => {
    const navigate = useNavigate();

    const handleMachineClick = (mac) => {
        navigate(`/mac/${mac.id}`, { state: { mac } });
    };

    return (
        <div className="manufacture-container">
            <h1 className="title">Our Machines</h1>
            <div className="machine-grid">
                {machines.map(mac => (
                    <div 
                        key={mac.id} 
                        className="machine-card" 
                        onClick={() => handleMachineClick(mac)}
                    >
                        <img 
                            src={mac.images[0]} 
                            alt={mac.name} 
                            className="machine-image" 
                        />
                        <h2>{mac.name}</h2>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Manufacture;
