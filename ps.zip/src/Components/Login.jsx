import React, { useState } from "react";
import { getFirestore, collection, query, where, getDocs } from "firebase/firestore";
import "./style.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleLogin = async (e) => {
    
    e.preventDefault(); // Prevent form submission

    try {
      const db = getFirestore();
      const q = query(
        collection(db, "register"),
        where("Email", "==", email),
        where("Password", "==", password)
      );
      
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        // Successful login
        console.log("Login successful!");
        alert("Login successful!");
        // Redirect or perform additional actions here
      } else {
        // Invalid credentials
        setErrorMessage("Invalid email or password.");
      }
    } catch (error) {
      console.error("Error during login:", error.message);
      setErrorMessage("Something went wrong. Please try again.");
    }
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleLogin}>
        <h2 className="form-title">Login</h2>
        {errorMessage && <p className="error-message">{errorMessage}</p>}
        <div className="input-group">
          <span className="icon">
            <i className="fas fa-user"></i>
          </span>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="input-group">
          <span className="icon">
            <i className="fas fa-lock"></i>
          </span>
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="form-options">
          <div>
            <input type="checkbox" id="remember-me" />
            <label htmlFor="remember-me">Remember Me</label>
          </div>
          <a href="/forgot-password" className="forgot-link">
            Forgot Password?
          </a>
        </div>
        <button type="submit" className="form-button">Login</button>
        <p className="register-link">
          Don't have an account? <a href="/register">Register</a>
        </p>
      </form>
    </div>
  );
};

export default Login;
