import React, { useState } from 'react';
import './About.css';
import {S1} from './S1';
import {Footer} from './Footer';

const About = () => {
    const [showForm, setShowForm] = useState(false);

    const handleGetQuoteClick = () => setShowForm(true);

    return (
        <>  <S1/>
        <section className="about-section-unique">
            <div className="about-container-unique">
                <h1>About PrintHub Machine Industries</h1>
                <p>
                    Welcome to <strong>PrintHub Machine Industries</strong>, a leading innovator in advanced screen printing solutions.
                    With years of experience, we specialize in designing and manufacturing high-performance printing machines
                    that redefine precision, speed, and efficiency.
                </p>

                <h2>Our History</h2>
                <p>
                    Founded in 1995, PrintHub Machine Industries began as a modest workshop with a vision to innovate the printing industry.
                    Through relentless dedication, we've achieved milestones such as developing India's first high-speed automated screen printer
                    and introducing eco-friendly ink solutions.
                </p>
                <p>
                    Our cutting-edge technology has transformed businesses globally, and we continue to invest in research and development to stay ahead.
                </p>

                <h2>Our Achievements</h2>
                <ul className="choose-us-list-unique">
                    <li>🏆 Best Industrial Printing Solution Award 2023</li>
                    <li>🌍 Innovation Excellence Award for Eco-Friendly Printing Solutions</li>
                    <li>🏅 Recognized as Top Manufacturer by Industry Leaders</li>
                </ul>

                <h2>Our Team</h2>
                <div className="team-container">
                    <div className="team-member">
                        <img src="/p1.jfif" alt="Lead Engineer" />
                        <h3>Ashok</h3>
                        <p className="team-role">Lead Engineer</p>
                    </div>
                    <div className="team-member">
                        <img src=" /p2.jfif" alt="Mechanic" />
                        <h3>Babu</h3>
                        <p className="team-role">Senior Mechanic</p>
                    </div>
                    <div className="team-member">
                        <img src="/p3.jfif" alt="Service Expert" />
                        <h3>Muthu Kumar</h3>
                        <p className="team-role">Service Specialist</p>
                    </div>
                    <div className="team-member">
                        <img src="/p4.jfif" alt="Sales Representative" />
                        <h3>Sankar</h3>
                        <p className="team-role">Sales Representative</p>
                    </div>
                </div>
            <div className='story'>
                <h2>Customer Success Stories</h2>
                <p>
                    "PrintHub's machines have improved our printing precision and productivity by 40%. Their support team provided seamless assistance throughout the process." - <em>Global Print Solutions Pvt. Ltd.</em>
                </p>
                <p>
                    "With PrintHub's technology, we cut waste and reduced ink costs by 30%. Outstanding service and top-notch products!" - <em>EcoPrint Industries</em>
                </p>

                <h2>Get a Quote</h2>
                <div className="contact-info">
                    <button className="quote-btn-unique" onClick={handleGetQuoteClick}>Get a Quote</button>
                </div>
                </div>
                {showForm && (
                    <div className="quote-form-unique">
                        <h3>Request a Custom Quote</h3>
                        <form>
                            <input type="text" placeholder="Your Name" required />
                            <input type="email" placeholder="Your Email" required />
                            <textarea placeholder="Your Requirements" rows="4" required></textarea>
                            <button type="submit">Submit Request</button>
                        </form>
                    </div>
                )}
            </div>
        </section>
        <Footer/> 
        </>
    );
};

export default About;
