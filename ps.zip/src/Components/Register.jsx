import React, { useState } from 'react';
import { FaUser, FaEnvelope, FaLock } from "react-icons/fa";
import './style.css';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth,db } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';

export const Register = () => {
  // State to hold form data
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cpassword, setCpassword] = useState('');
  
  // Firebase Auth instance
  const auth = getAuth();

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password !== cpassword) {
      alert("Passwords do not match!");
      return;
    }

    try {
      // Register the user with email and password
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Save user information in Firestore
      await addDoc(collection(db, 'register'), {
        Name: name,
        Email: email,
        Password: password,
        Cpassword: cpassword
      });

      alert('User registered successfully');
    } catch (error) {
      console.error("Error registering user:", error);
      alert("Error: " + error.message);
    }
  };

  return (
    <div className="Register-container">
      <div className='registerpage'>
        <div className='form-box'>
          <form onSubmit={handleSubmit}>
            <h1>Register</h1>
            <div className='input-box'>
              <input 
                type="text" 
                placeholder='Name' 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                required 
              />
              <FaUser className='icons'/>
            </div>
            <div className='input-box'>
              <input 
                type="email" 
                placeholder='Email' 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                required 
              />
              <FaEnvelope className='icons' />
            </div>
            <div className='input-box'>
              <input 
                type="password" 
                placeholder='Password' 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                required 
              />
              <FaLock className='icons'/>
            </div>
            <div className='input-box'>
              <input 
                type="password" 
                placeholder='Confirm Password' 
                value={cpassword} 
                onChange={(e) => setCpassword(e.target.value)} 
                required 
              />
              <FaLock className='icons'/>
            </div>
            <div className='forgot'>
              <label ><input type="checkbox" />Remember Me</label>
              <a href="#">Forgot Password</a>
            </div>
            <button type='submit'>Register</button>
            <div className='loginlink'>
              <p>Already have an account?<a href='/login'> Login</a></p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};