import React from 'react'
import Navbar from './Navbar'
import { A1 } from './A1';

export const Admin = () => {
  return (
    <div>
        <Navbar/>
        <A1/>
    </div>
  );
};
