import React from 'react'
import Navbar from './Navbar';
import {Footer} from './Footer'
import Manufacture from './Manufacture';
import { M1 } from './M1';
import {S1} from './S1';
export const Machine = () => {
  return (
    <>
        <Navbar></Navbar>
        <S1 />
        <Manufacture/>
        <M1/>
         <Footer/> 
    </>
  );
};
