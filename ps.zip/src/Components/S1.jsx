import React from 'react'
import './app1.css';

export const S1 = () => {
    return (
        <main className="landing-page">
            <div class="slider">
                <div class="slides">
                    <div class="slide">
                        <img src="img1.webp" alt="Machine 1"></img>
                        <div class="text"><h1>From concept to creation, we bring precision<br></br>and excellence to every print.</h1></div>
                    </div>
                    <div class="slide">
                        <img src="img2.webp" alt="Machine 2"></img>
                        <div class="text"><h1>In the world of printing, reliability is key to <br></br>delivering consistent, high-quality results</h1></div>
                    </div>
                    <div class="slide">
                        <img src="mac1.jpeg" alt="Machine 3"></img>
                        <div class="text"><h1>Every print tells a story trust the right <br></br>machine for flawless results.</h1></div>
                    </div>
                </div>
            </div>

               
        </main>
    );
};
