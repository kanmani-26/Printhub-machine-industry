import React from 'react'
import Navbar from './Navbar'
import { S1 } from './S1'
import { Footer } from './Footer'
import { Sale } from './Sale'
import MachineDetails from './MachineDetails'
import { Routes, Route } from "react-router-dom"; 

export const Sales = () => {
  return (
    <>
    <Navbar/>
    <S1/>
    <Routes>
        <Route path="/" element={<Sale />} />
        {/* <Route path="/machine/:id" element={<MachineDetails />} /> */}
      </Routes>
    <Footer/>
        </>
  )
}
